#ifndef I2C_TOF_H
#define I2C_TOF_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

// Initialize MSSP1 as I2C master at 100 kHz
// on RC0 (SCL) and RC1 (SDA), assuming Fosc = 16 MHz.
void i2c_tof_init(void);

// ---------- Low-level I2C primitives (polled) ----------

// Wait until MSSP1 bus is idle (no start/stop/ack in progress, no R/W)
void i2c_wait_idle(void);

// Generate a START condition
void i2c_start(void);

// Generate a REPEATED START condition
void i2c_repeated_start(void);

// Generate a STOP condition
void i2c_stop(void);

// Write one byte, return ACK status:
//   0 = ACK received
//   1 = NACK received
uint8_t i2c_write_byte(uint8_t data);

// Read one byte, then send ACK or NACK:
//   ack = true  ? send ACK (more data to come)
//   ack = false ? send NACK (last byte)
uint8_t i2c_read_byte(bool ack);


uint8_t i2c_read_reg(uint8_t reg);

void i2c_bus_recover_rc0_rc1(void);



#endif // I2C_TOF_H
