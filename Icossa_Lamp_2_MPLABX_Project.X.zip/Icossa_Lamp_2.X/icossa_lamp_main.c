/*
 * File:   icossa_lamp_mail.c
 * Author: leofernekes
 *
 * Created on November 28, 2025, 5:20 PM
 */


#include <xc.h>
#include "icossa_lamp_main.h"
#include "i2c_tof.h"
#include "vl53l0x_pic.h"
#include "pwm.h"





// ==================  Main ==================


int main(void)
{
    
 // Set internal oscillator to 16 MHz HFINTOSC
    // pick HFINTOSC = 16 MHz
    OSCFRQbits.HFFRQ = 0b101;      // 16 MHz
    // no divider
    OSCCON1bits.NDIV = 0b0000;     // /1
    // ensure we are actually running from HFINTOSC
    // (field name varies; some headers use NOSC, some use NOSCbits)
    OSCCON1bits.NOSC = 0b110;      // HFINTOSC
    while (!OSCCON3bits.ORDY) {;}  // wait for switch complete  
    
//watchdog setup 
    // Ensure prescaler is correct (optional safety)
    WDTCON0bits.WDTPS = 0b1001; // 2^9 ? 512 ms
    WDTCON1bits.WDTCS = 0b000; //select MFINTOSC
    // Enable WDT
    WDTCON0bits.SWDTEN = 0;
    CLRWDT();  // start with a full timeout window
    
        
 //diagnostic DAC setup   
    DAC1CON0bits.DAC1EN = 1; //Enable DAC
    DAC1CON0bits.DAC1OE1 = 1; // enable output on RA0 for diags 
 
    i2c_bus_recover_rc0_rc1();
    
    
    init_pwm3_rc5(); // Init PWM Engine
    i2c_tof_init();    // I2C on RC0/RC1
    timer1_init_1ms_tick();
    
    LATAbits.LATA2 = 1;// DIAGNOSTIC OUT 
    __delay_ms(10);    // let sensor boot
    LATAbits.LATA2 = 0;// DIAGNOSTIC OUT  
    

   if (!vl53_init(true))
    {
        // error blink
        while (1)
        {
            pwm3_set_duty_10bit(0);
            __delay_ms(80);
            pwm3_set_duty_10bit(1023);
            __delay_ms(80);
        }
    }

    // ~20 ms timing budget (~50 Hz)
   vl53_setMeasurementTimingBudget(20000);

    // Start continuous mode
    //  20 ? ~20 ms inter-measurement (timed)
    vl53_startContinuous(0);

    uint16_t d = 0;

    while (1)
    {
        
        brightness_update_exp(); // manage dimming engine 
        
          // ---- Non-blocking VL53 task ----      
        if (vl53_pollRangeContinuousMillimeters(&d))
            
        {
            // We only get here when a NEW sample arrived.
            CLRWDT(); // system is running correctly - reset WDT
//            LATAbits.LATA2 = ! LATAbits.LATA2; //digagnostic
            
            uint16_t duty;

            if (d >= MAX_MM || d <= MIN_MM ) // check overall limits
            {
            duty = 0;
            hand_present = false; 
            LATAbits.LATA2 = 0;// DIAGNOSTIC OUT
            }
            else
            {
            hand_present = true;
            LATAbits.LATA2 = 1;// DIAGNOSTIC OUT            
            }
            
//          DAC1CON1  = gesture_state; // diagnostic switch state to DAC for monitoring
            DAC1CON1  = (d >> 4);// direct output of sensor signal
            
            switch (gesture_state)
            
            {
            
                case 0: //looking for RISING EDGE
                    if (hand_present)
                    {
                    gesture_timer_long = GESTURE_TO_LONG;
                    gesture_timer_short = GESTURE_TO_SHORT;
                    gesture_state =1; //advance to next state
                    }    
                break;

                case 1: //looking for first FALLING edge
                    if (hand_present)
                    {
                        if (! gesture_timer_long) //timeout, hand still there
                        {
                            if (lamp_on)
                            {
                            gesture_state= 5;// change to active dimming mode
                            }
                            else  
                            {
                            gesture_state= 6;// change to idle dim mode
                            }              
                        }
                    }    
                    else // hand NOT present -falling edge!
                    {
                        if (gesture_timer_long && !gesture_timer_short ) //valid first swipe- within time window  
                        {
                        gesture_state= 2;//reset timer and advance to next state
                        gesture_timer_long = GESTURE_TO_LONG;
                        gesture_timer_short = GESTURE_TO_SHORT;                        
                        } 
                        else
                        {
                        gesture_state= 0; // error - reset.}  
                        }
                        
                    }
                    
                    
                break;           
            
                case 2: // looking for second rising edge

                    if(hand_present)
                    {
                        if(gesture_timer_short)
                        {
                        gesture_state= 0; // error - reset, way too fast
                        break;
                        }
                        
                    gesture_timer_long = GESTURE_TO_LONG;
                    gesture_timer_short = GESTURE_TO_SHORT;
                    gesture_state =3; //advance to next state                    
                    }
                    else // hand not present
                    {
                        if (! gesture_timer_long) //timeout, hand still NOT there
                        {
                        gesture_state= 0;// reset, reject glitch
                        }                     
                    }
                    
                    
                break;           
            
                case 3: //looking for second FALLING edge
                    if (hand_present)
                    {
                        if (! gesture_timer_long) //timeout, hand still there
                        {
                        gesture_state= 0;// timeout- reset
                        }    
                    }
                    else // hand NOT present
                    {
                        if (gesture_timer_long && !gesture_timer_short ) //valid first swipe   
                        {
                        lamp_on = !lamp_on; //toggle the state of lamp 
                            if (lamp_on) 
                            {
                            brightness_target = brightness_last; // return to last setting
                            }
                            else
                            {
                            brightness_target = 0;  // shutdown lamp                         
                            }
                        
                        gesture_state= 0;// reset state
                        }    
                    }               
                break;           
            
                case 4:// wait for hand to release- then return to mode 0

                    if (!hand_present)
                    {
                    gesture_state =0; //reset
                    }                  
                    
                    
                break;           
            
                case 5: // active dimming mode with lamp on
        
                    if (hand_present)
                    {    
                    int32_t i;                
                    i = (MAX_MM - DIM_OFFSET);
                        if (d > i) // check for underflow borrow condition
                        {
                        i=0;
                        }   
                        else
                        {
                        i = i - d; // subtract- invert sense of direction
                        }

                    i = (i * DIM_SCALE); // scale the values to produce full-scale light
                        if (i > 32767)
                        {   
                        i = 32767;
                        }

                        if (i < DIM_CLAMP)// lower brightness level clamp
                        {
                        i = DIM_CLAMP;
                        }                        
                        
                    brightness_target = i;
                    brightness_last = brightness_target; // save the value as default
                    delay_filter(brightness_target); // save the sample in rolling delay filter
                    }
                    else  //hand not present
                    {
                    gesture_state= 0;//  reset system             
                    brightness_target =  delay_filter(0); // use old value - prevent trail off  
                    brightness_last = brightness_target; // save the value as default                    
                    }    
                break; 
                
                
                case 6: // dim mode with LAMP OFF
                     if (!hand_present)
                    {
                    gesture_state =0; //reset
                    }                   
 
                break;
                
                
                
                default:
                break;
                
            }//switch

               
            }//poll range

      
        __delay_ms(1);
        
         
    }//while 1 loop
        
}//main
