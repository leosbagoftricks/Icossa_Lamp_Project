


/**
 * i2c_tof.c
 *
 * MSSP1 I2C init + low-level primitives for PIC16LF1455
 * to talk to a VL53L0X / other I2C peripherals.
 *
 * Assumptions:
 *  - Device: PIC16LF1455
 *  - Fosc  = 16 MHz (HFINTOSC)
 *  - I2C master at 100 kHz
 *  - SCL = RC0, SDA = RC1
 */

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "i2c_tof.h"
#include "vl53l0x_pic.h"
#include "pwm.h"

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000UL
#endif

// -------------------------------------------------------
// I2C INIT (MSSP1 master @ 100 kHz on RC0/RC1)
// -------------------------------------------------------

void i2c_tof_init(void)
{
    // Make SCL/SDA digital
    ANSELCbits.ANSC0 = 0;    // RC0 digital (SCL)
    ANSELCbits.ANSC1 = 0;    // RC1 digital (SDA)

    TRISCbits.TRISC0 = 1;    // SCL input (MSSP drives it)
    TRISCbits.TRISC1 = 1;    // SDA input
    

    
    // Disable MSSP while configuring
    SSP1CON1bits.SSPEN = 0;

    // I2C Master mode: SSPM = 0b1000 ? Fosc / (4 * (SSP1ADD + 1))
    SSP1CON1bits.SSPM = 0b1000;

    // Standard mode I2C (100 kHz): slew rate off, standard levels
    SSP1STATbits.SMP = 1;
    SSP1STATbits.CKE = 0;

    // Clear control bits (start/stop/ack state)
    SSP1CON2 = 0x00;

    // Set bit rate: 100 kHz @ 16 MHz
    // SSP1ADD = (Fosc / (4 * F_I2C)) - 1
    //         = (16e6 / (4 * 100e3)) - 1
    //         = 40 - 1 = 39 = 0x27
    SSP1ADD = (uint8_t)((_XTAL_FREQ / (4UL * 100000UL)) - 1UL);

    // Clear MSSP interrupt flag (we're polling)
    PIR3bits.SSP1IF = 0;

    // Enable MSSP1
    SSP1CON1bits.SSPEN = 1;
}




// -------------------------------------------------------
// Low-level MSSP1 I2C primitives (polled)
// -------------------------------------------------------

void i2c_wait_idle(void)
{
    // Wait until:
    //  - No Start/Stop/Restart/Ack in progress (SSP1CON2 lower 5 bits clear)
    //  - No R/W in progress (R_nW = 0)
    while ((SSP1CON2 & 0x1F) || (SSP1STATbits.R_nW)) {
        // spin
    }
}

void i2c_start(void)
{
    i2c_wait_idle();
    SSP1CON2bits.SEN = 1;            // initiate START
    while (SSP1CON2bits.SEN) {
        // wait for start to complete
    }
}

void i2c_repeated_start(void)
{
    i2c_wait_idle();
    SSP1CON2bits.RSEN = 1;           // initiate REPEATED START
    while (SSP1CON2bits.RSEN) {
        // wait for restart to complete
    }
}

void i2c_stop(void)
{
    i2c_wait_idle();
    SSP1CON2bits.PEN = 1;            // initiate STOP
    while (SSP1CON2bits.PEN) {
        // wait for stop to complete
    }
}

uint8_t i2c_write_byte(uint8_t data)
{
    i2c_wait_idle();
    SSP1BUF = data;                  // load data to transmit

    while (!PIR3bits.SSP1IF) {
        // wait for transmit to complete
    }
    PIR3bits.SSP1IF = 0;             // clear flag

    // ACKSTAT: 0 = ACK received, 1 = NACK
    return (uint8_t)SSP1CON2bits.ACKSTAT;
}

uint8_t i2c_read_byte(bool ack)
{
    uint8_t data;

    i2c_wait_idle();
    SSP1CON2bits.RCEN = 1;           // enable receive mode

    // Wait until buffer full
    while (!SSP1STATbits.BF) {
        // waiting for byte to arrive
    }
    data = SSP1BUF;

    i2c_wait_idle();
    SSP1CON2bits.ACKDT = ack ? 0 : 1; // 0 = send ACK, 1 = send NACK
    SSP1CON2bits.ACKEN = 1;           // send ACK/NACK
    while (SSP1CON2bits.ACKEN) {
        // wait for ACK/NACK to complete
    }

    return data;
}


// -------------------------------------------------------
// Simple VL53L0X register read helpers
// -------------------------------------------------------

#define VL53_I2C_ADDR  0x29      // 7-bit address (sensor default)

// Write register address (no data)
static void i2c_write_reg_addr(uint8_t reg)
{
    i2c_start();
    i2c_write_byte((VL53_I2C_ADDR << 1) | 0);   // write mode
    i2c_write_byte(reg);
}

// Read 1 byte from register
uint8_t i2c_read_reg(uint8_t reg)
{
    uint8_t val;

    // Send register address first
    i2c_write_reg_addr(reg);

    // Repeated start ? switch to read mode
    i2c_repeated_start();
    i2c_write_byte((VL53_I2C_ADDR << 1) | 1);   // read mode

    // Read single byte and NACK it
    val = i2c_read_byte(false);

    i2c_stop();
    return val;
}


void i2c_bus_recover_rc0_rc1(void)
{
    // Make sure pins are digital
    ANSELCbits.ANSC0 = 0;
    ANSELCbits.ANSC1 = 0;

    // Disable MSSP so it can't fight you
    SSP1CON1bits.SSPEN = 0;

    // Release both lines (inputs = high via pull-ups)
    TRISCbits.TRISC0 = 1;  // SCL released
    TRISCbits.TRISC1 = 1;  // SDA released

    __delay_us(5);

    // If SDA is low, try to free it by clocking SCL
    if (PORTCbits.RC1 == 0)
    {
        for (uint8_t i = 0; i < 9; i++)
        {
            // Drive SCL low
            LATCbits.LATC0 = 0;
            TRISCbits.TRISC0 = 0;
            __delay_us(5);

            // Release SCL high
            TRISCbits.TRISC0 = 1;
            __delay_us(5);

            // If SDA released early, we can stop clocking
            if (PORTCbits.RC1) break;
        }

        // Generate a STOP condition manually:
        // SDA low while SCL high -> then release SDA high.
        // Drive SDA low
        LATCbits.LATC1 = 0;
        TRISCbits.TRISC1 = 0;
        __delay_us(5);

        // Ensure SCL is high (released)
        TRISCbits.TRISC0 = 1;
        __delay_us(5);

        // Release SDA high (STOP)
        TRISCbits.TRISC1 = 1;
        __delay_us(5);
    }
}




