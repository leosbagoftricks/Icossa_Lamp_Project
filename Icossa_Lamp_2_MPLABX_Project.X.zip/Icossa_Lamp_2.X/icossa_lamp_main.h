/* Microchip Technology Inc. and its subsidiaries.  You may use this software 
 * and any derivatives exclusively with Microchip products. 
 * 
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES, WHETHER 
 * EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED 
 * WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A 
 * PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION 
 * WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
 * INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
 * WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS 
 * BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE 
 * FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS 
 * IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF 
 * ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE 
 * TERMS. 
 */

/* 
 * File:   
 * Author: 
 * Comments:
 * Revision history: 
 */

// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.  

#ifndef PWM16F1455_H
#define PWM16F1455_H

#include <stdint.h>
#include "configs.h"
#include <stdbool.h>
// Call once at startup:
// - sets internal oscillator to 16 MHz
// - configures PWM1 to output 10-bit PWM on RC5
void system_init(void);

// Set PWM1 duty cycle (0?1023 = 0?100%)
// Values above 1023 are clamped.
void pwm1_set_duty_10bit(uint16_t duty);
void brightness_update_exp(void);
static void init_osc_16MHz(void);


uint16_t brightness_target =16384;
uint16_t brightness_actual =0;
uint16_t brightness_last =16384; //default starting point

volatile uint16_t gesture_timer_long = 0;
volatile uint16_t gesture_timer_short = 0;

volatile bool lamp_on = true;
volatile bool hand_present = false;
volatile uint8_t gesture_state =0;
volatile uint16_t brightness_timer =0;



#define  MAX_MM  300 //define sensing range upper
#define  MIN_MM  20 //define sensing range lower
#define  DIM_SCALE 150 //scale the sensor data to brightness level
#define  DIM_OFFSET 80 // offset from bottom, still active but bottom of dim range
#define  DIM_CLAMP 1000 //lowest possible brightness while still ON

//max brightness range = 32768
// (MAX_MM - DIM_OFFSET) = raw value
// raw value * DIM_SCALE = signal to dimmer

#define GESTURE_TO_LONG 300
#define GESTURE_TO_SHORT 40 


#define _XTAL_FREQ 16000000UL     // 16 MHz HFINTOSC (for __delay_ms/us)




#endif // PWM16F1455_H





#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    // TODO If C++ is being used, regular C code needs function names to have C 
    // linkage so the functions can be used by the c code. 

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

