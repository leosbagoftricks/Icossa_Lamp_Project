/*
 * File:   vl53l0x_pic.c
 * Author: leofernekes
 *
 * Created on November 30, 2025, 11:28 AM
 */


#include <xc.h>
#include <stdint.h>
#include <stdbool.h>

#include "vl53l0x_pic.h"
#include "i2c_tof.h"
#include "icossa_lamp_main.h"


#ifndef _XTAL_FREQ
#define _XTAL_FREQ 16000000UL
#endif

// ======== internal state (single sensor instance) ========
static uint16_t io_timeout = 0;      // ms, 0 = no timeout
static bool     did_timeout = false;
static uint16_t timeout_start_ms = 0; // NOT actually used (no millis)
static uint8_t  stop_variable = 0;
static uint32_t measurement_timing_budget_us = 0;
static uint8_t  last_status = 0;

// Arduino macros: here we just disable timeouts (no millis on PIC)
#define startTimeout()       do { /* no-op */ } while(0)
#define checkTimeoutExpired() (false)

// VCSEL period encode/decode and macro period
#define decodeVcselPeriod(reg_val)      (((reg_val) + 1U) << 1)
#define encodeVcselPeriod(period_pclks) (((period_pclks) >> 1) - 1U)

// PLL_period_ps = 1655; macro_period_vclks = 2304
#define calcMacroPeriod(vcsel_period_pclks) \
    ((((uint32_t)2304 * (vcsel_period_pclks) * 1655U) + 500U) / 1000U)

// ---- forward declarations of internal helpers ----
static void     writeReg(uint8_t reg, uint8_t value);
static void     writeReg16Bit(uint8_t reg, uint16_t value);
static void     writeReg32Bit(uint8_t reg, uint32_t value);
static uint8_t  readReg(uint8_t reg);
static uint16_t readReg16Bit(uint8_t reg);
static uint32_t readReg32Bit(uint8_t reg);
static void     writeMulti(uint8_t reg, const uint8_t *src, uint8_t count);
static void     readMulti(uint8_t reg, uint8_t *dst, uint8_t count);

typedef struct
{
    bool tcc, msrc, dss, pre_range, final_range;
} SequenceStepEnables;

typedef struct
{
    uint16_t pre_range_vcsel_period_pclks;
    uint16_t final_range_vcsel_period_pclks;

    uint16_t msrc_dss_tcc_mclks;
    uint16_t pre_range_mclks;
    uint16_t final_range_mclks;

    uint32_t msrc_dss_tcc_us;
    uint32_t pre_range_us;
    uint32_t final_range_us;
} SequenceStepTimeouts;

static bool     getSpadInfo(uint8_t *count, bool *type_is_aperture);
static void     getSequenceStepEnables(SequenceStepEnables *enables);
static void     getSequenceStepTimeouts(const SequenceStepEnables *enables,
                                        SequenceStepTimeouts *timeouts);
static bool     performSingleRefCalibration(uint8_t vhv_init_byte);
static uint16_t decodeTimeout(uint16_t value);
static uint16_t encodeTimeout(uint32_t timeout_mclks);
static uint32_t timeoutMclksToMicroseconds(uint16_t timeout_period_mclks,
                                            uint8_t vcsel_period_pclks);
static uint32_t timeoutMicrosecondsToMclks(uint32_t timeout_period_us,
                                            uint8_t vcsel_period_pclks);

// ===========================================================
// LOW-LEVEL I2C ACCESS (Wire ? i2c_tof)
// ===========================================================

static void writeReg(uint8_t reg, uint8_t value)
{
    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0); // write
    i2c_write_byte(reg);
    last_status = i2c_write_byte(value);         // we just store ACK/NACK
    i2c_stop();
}

static void writeReg16Bit(uint8_t reg, uint16_t value)
{
    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);
    i2c_write_byte((uint8_t)(value >> 8));   // high
    last_status = i2c_write_byte((uint8_t)value); // low
    i2c_stop();
}

static void writeReg32Bit(uint8_t reg, uint32_t value)
{
    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);
    i2c_write_byte((uint8_t)(value >> 24));
    i2c_write_byte((uint8_t)(value >> 16));
    i2c_write_byte((uint8_t)(value >> 8));
    last_status = i2c_write_byte((uint8_t)value);
    i2c_stop();
}

static uint8_t readReg(uint8_t reg)
{
    uint8_t value;

    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0); // write
    i2c_write_byte(reg);

    i2c_repeated_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 1); // read

    value = i2c_read_byte(false); // single byte ? NACK
    i2c_stop();

    return value;
}

static uint16_t readReg16Bit(uint8_t reg)
{
    uint16_t value;
    uint8_t hi, lo;

    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);

    i2c_repeated_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 1);

    hi = i2c_read_byte(true);   // ACK first
    lo = i2c_read_byte(false);  // NACK last
    i2c_stop();

    value  = ((uint16_t)hi << 8);
    value |= lo;
    return value;
}

static uint32_t readReg32Bit(uint8_t reg)
{
    uint8_t b0, b1, b2, b3;
    uint32_t value;

    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);

    i2c_repeated_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 1);

    b0 = i2c_read_byte(true);
    b1 = i2c_read_byte(true);
    b2 = i2c_read_byte(true);
    b3 = i2c_read_byte(false);
    i2c_stop();

    value  = ((uint32_t)b0 << 24);
    value |= ((uint32_t)b1 << 16);
    value |= ((uint32_t)b2 << 8);
    value |= b3;
    return value;
}

static void writeMulti(uint8_t reg, const uint8_t *src, uint8_t count)
{
    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);
    while (count-- > 0)
    {
        i2c_write_byte(*src++);
    }
    i2c_stop();
}

static void readMulti(uint8_t reg, uint8_t *dst, uint8_t count)
{
    i2c_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 0);
    i2c_write_byte(reg);

    i2c_repeated_start();
    i2c_write_byte((VL53L0X_I2C_ADDR << 1) | 1);

    while (count--)
    {
        bool ack = (count != 0);
        *dst++ = i2c_read_byte(ack);
    }
    i2c_stop();
}

// ===========================================================
// PUBLIC API ? direct C port of VL53L0X::init/startContinuous/... :contentReference[oaicite:1]{index=1}
// ===========================================================

bool vl53_init(bool io_2v8)
{
    // check model ID register (should be 0xEE)
    if (readReg(IDENTIFICATION_MODEL_ID) != 0xEE)
    {
        return false;
    }

    // VL53L0X_DataInit:

    // I/O 2.8V mode if requested
    if (io_2v8)
    {
        uint8_t vhv = readReg(VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV);
        writeReg(VHV_CONFIG_PAD_SCL_SDA__EXTSUP_HV, vhv | 0x01);
    }

    // "Set I2C standard mode"
    writeReg(0x88, 0x00);

    writeReg(0x80, 0x01);
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);
    stop_variable = readReg(0x91);
    writeReg(0x00, 0x01);
    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x00);

    // disable SIGNAL_RATE_MSRC and SIGNAL_RATE_PRE_RANGE limit checks
    writeReg(MSRC_CONFIG_CONTROL, readReg(MSRC_CONFIG_CONTROL) | 0x12);

    // set final range signal rate limit to 0.25 MCPS
    // (default used by Pololu)
    vl53_setMeasurementTimingBudget(33000); // will recompute below
    // they call setSignalRateLimit(0.25); we inline it:
    writeReg16Bit(FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT,
                  (uint16_t)(0.25f * (1 << 7)));

    writeReg(SYSTEM_SEQUENCE_CONFIG, 0xFF);

    // VL53L0X_StaticInit:

    uint8_t spad_count;
    bool spad_type_is_aperture;
    if (!getSpadInfo(&spad_count, &spad_type_is_aperture))
    {
        return false;
    }

    uint8_t ref_spad_map[6];
    readMulti(GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);

    writeReg(0xFF, 0x01);
    writeReg(DYNAMIC_SPAD_REF_EN_START_OFFSET, 0x00);
    writeReg(DYNAMIC_SPAD_NUM_REQUESTED_REF_SPAD, 0x2C);
    writeReg(0xFF, 0x00);
    writeReg(GLOBAL_CONFIG_REF_EN_START_SELECT, 0xB4);

    uint8_t first_spad_to_enable = spad_type_is_aperture ? 12 : 0;
    uint8_t spads_enabled = 0;

    for (uint8_t i = 0; i < 48; i++)
    {
        if (i < first_spad_to_enable || spads_enabled == spad_count)
        {
            ref_spad_map[i / 8] &= ~(1 << (i % 8));
        }
        else if ((ref_spad_map[i / 8] >> (i % 8)) & 0x1)
        {
            spads_enabled++;
        }
    }

    writeMulti(GLOBAL_CONFIG_SPAD_ENABLES_REF_0, ref_spad_map, 6);

    // --- load tuning settings (DefaultTuningSettings) ---
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);

    writeReg(0xFF, 0x00);
    writeReg(0x09, 0x00);
    writeReg(0x10, 0x00);
    writeReg(0x11, 0x00);

    writeReg(0x24, 0x01);
    writeReg(0x25, 0xFF);
    writeReg(0x75, 0x00);

    writeReg(0xFF, 0x01);
    writeReg(0x4E, 0x2C);
    writeReg(0x48, 0x00);
    writeReg(0x30, 0x20);

    writeReg(0xFF, 0x00);
    writeReg(0x30, 0x09);
    writeReg(0x54, 0x00);
    writeReg(0x31, 0x04);
    writeReg(0x32, 0x03);
    writeReg(0x40, 0x83);
    writeReg(0x46, 0x25);
    writeReg(0x60, 0x00);
    writeReg(0x27, 0x00);
    writeReg(0x50, 0x06);
    writeReg(0x51, 0x00);
    writeReg(0x52, 0x96);
    writeReg(0x56, 0x08);
    writeReg(0x57, 0x30);
    writeReg(0x61, 0x00);
    writeReg(0x62, 0x00);
    writeReg(0x64, 0x00);
    writeReg(0x65, 0x00);
    writeReg(0x66, 0xA0);

    writeReg(0xFF, 0x01);
    writeReg(0x22, 0x32);
    writeReg(0x47, 0x14);
    writeReg(0x49, 0xFF);
    writeReg(0x4A, 0x00);

    writeReg(0xFF, 0x00);
    writeReg(0x7A, 0x0A);
    writeReg(0x7B, 0x00);
    writeReg(0x78, 0x21);

    writeReg(0xFF, 0x01);
    writeReg(0x23, 0x34);
    writeReg(0x42, 0x00);
    writeReg(0x44, 0xFF);
    writeReg(0x45, 0x26);
    writeReg(0x46, 0x05);
    writeReg(0x40, 0x40);
    writeReg(0x0E, 0x06);
    writeReg(0x20, 0x1A);
    writeReg(0x43, 0x40);

    writeReg(0xFF, 0x00);
    writeReg(0x34, 0x03);
    writeReg(0x35, 0x44);

    writeReg(0xFF, 0x01);
    writeReg(0x31, 0x04);
    writeReg(0x4B, 0x09);
    writeReg(0x4C, 0x05);
    writeReg(0x4D, 0x04);

    writeReg(0xFF, 0x00);
    writeReg(0x44, 0x00);
    writeReg(0x45, 0x20);
    writeReg(0x47, 0x08);
    writeReg(0x48, 0x28);
    writeReg(0x67, 0x00);
    writeReg(0x70, 0x04);
    writeReg(0x71, 0x01);
    writeReg(0x72, 0xFE);
    writeReg(0x76, 0x00);
    writeReg(0x77, 0x00);

    writeReg(0xFF, 0x01);
    writeReg(0x0D, 0x01);

    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x01);
    writeReg(0x01, 0xF8);

    writeReg(0xFF, 0x01);
    writeReg(0x8E, 0x01);
    writeReg(0x00, 0x01);
    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x00);

    // "Set interrupt config to new sample ready"
    writeReg(SYSTEM_INTERRUPT_CONFIG_GPIO, 0x04);
    writeReg(GPIO_HV_MUX_ACTIVE_HIGH,
             readReg(GPIO_HV_MUX_ACTIVE_HIGH) & (uint8_t)~0x10);
    writeReg(SYSTEM_INTERRUPT_CLEAR, 0x01);

    measurement_timing_budget_us = vl53_getMeasurementTimingBudget();

    // Disable MSRC and TCC by default
    writeReg(SYSTEM_SEQUENCE_CONFIG, 0xE8);

    // Recalculate timing budget
    vl53_setMeasurementTimingBudget(measurement_timing_budget_us);

    // Ref calibration (VHV + phase)
    writeReg(SYSTEM_SEQUENCE_CONFIG, 0x01);
    if (!performSingleRefCalibration(0x40)) return false;

    writeReg(SYSTEM_SEQUENCE_CONFIG, 0x02);
    if (!performSingleRefCalibration(0x00)) return false;

    writeReg(SYSTEM_SEQUENCE_CONFIG, 0xE8);

    return true;
}

// Timeouts (dummy/no-op implementation)
void vl53_setTimeout(uint16_t timeout_ms)
{
    io_timeout = timeout_ms;
}

uint16_t vl53_getTimeout(void)
{
    return io_timeout;
}

bool vl53_timeoutOccurred(void)
{
    bool tmp = did_timeout;
    did_timeout = false;
    return tmp;
}

// Signal rate limit helpers
static bool setSignalRateLimit(float limit_Mcps)
{
    if (limit_Mcps < 0.0f || limit_Mcps > 511.99f) return false;
    uint16_t val = (uint16_t)(limit_Mcps * (1 << 7));
    writeReg16Bit(FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT, val);
    return true;
}

static float getSignalRateLimit(void)
{
    uint16_t v = readReg16Bit(FINAL_RANGE_CONFIG_MIN_COUNT_RATE_RTN_LIMIT);
    return (float)v / (float)(1 << 7);
}

// Measurement timing budget API
bool vl53_setMeasurementTimingBudget(uint32_t budget_us)
{
    SequenceStepEnables enables;
    SequenceStepTimeouts timeouts;

    uint16_t const StartOverhead     = 1910;
    uint16_t const EndOverhead       = 960;
    uint16_t const MsrcOverhead      = 660;
    uint16_t const TccOverhead       = 590;
    uint16_t const DssOverhead       = 690;
    uint16_t const PreRangeOverhead  = 660;
    uint16_t const FinalRangeOverhead= 550;

    uint32_t used_budget_us = StartOverhead + EndOverhead;

    getSequenceStepEnables(&enables);
    getSequenceStepTimeouts(&enables, &timeouts);

    if (enables.tcc)
    {
        used_budget_us += timeouts.msrc_dss_tcc_us + TccOverhead;
    }

    if (enables.dss)
    {
        used_budget_us += 2 * (timeouts.msrc_dss_tcc_us + DssOverhead);
    }
    else if (enables.msrc)
    {
        used_budget_us += timeouts.msrc_dss_tcc_us + MsrcOverhead;
    }

    if (enables.pre_range)
    {
        used_budget_us += timeouts.pre_range_us + PreRangeOverhead;
    }

    if (enables.final_range)
    {
        used_budget_us += FinalRangeOverhead;

        if (used_budget_us > budget_us)
        {
            return false; // requested too small
        }

        uint32_t final_range_timeout_us = budget_us - used_budget_us;

        uint32_t final_range_timeout_mclks =
            timeoutMicrosecondsToMclks(final_range_timeout_us,
                                       timeouts.final_range_vcsel_period_pclks);

        if (enables.pre_range)
        {
            final_range_timeout_mclks += timeouts.pre_range_mclks;
        }

        writeReg16Bit(FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI,
                      encodeTimeout(final_range_timeout_mclks));

        measurement_timing_budget_us = budget_us;
    }

    return true;
}

uint32_t vl53_getMeasurementTimingBudget(void)
{
    SequenceStepEnables enables;
    SequenceStepTimeouts timeouts;

    uint16_t const StartOverhead     = 1910;
    uint16_t const EndOverhead       = 960;
    uint16_t const MsrcOverhead      = 660;
    uint16_t const TccOverhead       = 590;
    uint16_t const DssOverhead       = 690;
    uint16_t const PreRangeOverhead  = 660;
    uint16_t const FinalRangeOverhead= 550;

    uint32_t budget_us = StartOverhead + EndOverhead;

    getSequenceStepEnables(&enables);
    getSequenceStepTimeouts(&enables, &timeouts);

    if (enables.tcc)
        budget_us += timeouts.msrc_dss_tcc_us + TccOverhead;

    if (enables.dss)
        budget_us += 2 * (timeouts.msrc_dss_tcc_us + DssOverhead);
    else if (enables.msrc)
        budget_us += timeouts.msrc_dss_tcc_us + MsrcOverhead;

    if (enables.pre_range)
        budget_us += timeouts.pre_range_us + PreRangeOverhead;

    if (enables.final_range)
        budget_us += timeouts.final_range_us + FinalRangeOverhead;

    measurement_timing_budget_us = budget_us;
    return budget_us;
}

// VCSEL period control
bool vl53_setVcselPulsePeriod(vl53_vcselPeriodType_t type,
                              uint8_t period_pclks)
{
    uint8_t vcsel_period_reg = encodeVcselPeriod(period_pclks);

    SequenceStepEnables enables;
    SequenceStepTimeouts timeouts;

    getSequenceStepEnables(&enables);
    getSequenceStepTimeouts(&enables, &timeouts);

    if (type == VcselPeriodPreRange)
    {
        switch (period_pclks)
        {
            case 12: writeReg(PRE_RANGE_CONFIG_VALID_PHASE_HIGH, 0x18); break;
            case 14: writeReg(PRE_RANGE_CONFIG_VALID_PHASE_HIGH, 0x30); break;
            case 16: writeReg(PRE_RANGE_CONFIG_VALID_PHASE_HIGH, 0x40); break;
            case 18: writeReg(PRE_RANGE_CONFIG_VALID_PHASE_HIGH, 0x50); break;
            default: return false;
        }
        writeReg(PRE_RANGE_CONFIG_VALID_PHASE_LOW, 0x08);

        writeReg(PRE_RANGE_CONFIG_VCSEL_PERIOD, vcsel_period_reg);

        uint16_t new_pre_range_timeout_mclks =
            timeoutMicrosecondsToMclks(timeouts.pre_range_us, period_pclks);

        writeReg16Bit(PRE_RANGE_CONFIG_TIMEOUT_MACROP_HI,
                      encodeTimeout(new_pre_range_timeout_mclks));

        uint16_t new_msrc_timeout_mclks =
            timeoutMicrosecondsToMclks(timeouts.msrc_dss_tcc_us, period_pclks);

        writeReg(MSRC_CONFIG_TIMEOUT_MACROP,
                 (new_msrc_timeout_mclks > 256) ? 255 : (new_msrc_timeout_mclks - 1));
    }
    else if (type == VcselPeriodFinalRange)
    {
        switch (period_pclks)
        {
            case 8:
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_HIGH, 0x10);
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_LOW,  0x08);
                writeReg(GLOBAL_CONFIG_VCSEL_WIDTH, 0x02);
                writeReg(ALGO_PHASECAL_CONFIG_TIMEOUT, 0x0C);
                writeReg(0xFF, 0x01);
                writeReg(ALGO_PHASECAL_LIM, 0x30);
                writeReg(0xFF, 0x00);
                break;

            case 10:
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_HIGH, 0x28);
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_LOW,  0x08);
                writeReg(GLOBAL_CONFIG_VCSEL_WIDTH, 0x03);
                writeReg(ALGO_PHASECAL_CONFIG_TIMEOUT, 0x09);
                writeReg(0xFF, 0x01);
                writeReg(ALGO_PHASECAL_LIM, 0x20);
                writeReg(0xFF, 0x00);
                break;

            case 12:
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_HIGH, 0x38);
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_LOW,  0x08);
                writeReg(GLOBAL_CONFIG_VCSEL_WIDTH, 0x03);
                writeReg(ALGO_PHASECAL_CONFIG_TIMEOUT, 0x08);
                writeReg(0xFF, 0x01);
                writeReg(ALGO_PHASECAL_LIM, 0x20);
                writeReg(0xFF, 0x00);
                break;

            case 14:
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_HIGH, 0x48);
                writeReg(FINAL_RANGE_CONFIG_VALID_PHASE_LOW,  0x08);
                writeReg(GLOBAL_CONFIG_VCSEL_WIDTH, 0x03);
                writeReg(ALGO_PHASECAL_CONFIG_TIMEOUT, 0x07);
                writeReg(0xFF, 0x01);
                writeReg(ALGO_PHASECAL_LIM, 0x20);
                writeReg(0xFF, 0x00);
                break;

            default:
                return false;
        }

        writeReg(FINAL_RANGE_CONFIG_VCSEL_PERIOD, vcsel_period_reg);

        uint16_t new_final_range_timeout_mclks =
            timeoutMicrosecondsToMclks(timeouts.final_range_us, period_pclks);

        if (enables.pre_range)
        {
            new_final_range_timeout_mclks += timeouts.pre_range_mclks;
        }

        writeReg16Bit(FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI,
                      encodeTimeout(new_final_range_timeout_mclks));
    }
    else
    {
        return false;
    }

    vl53_setMeasurementTimingBudget(measurement_timing_budget_us);

    uint8_t sequence_config = readReg(SYSTEM_SEQUENCE_CONFIG);
    writeReg(SYSTEM_SEQUENCE_CONFIG, 0x02);
    performSingleRefCalibration(0x00);
    writeReg(SYSTEM_SEQUENCE_CONFIG, sequence_config);

    return true;
}

uint8_t vl53_getVcselPulsePeriod(vl53_vcselPeriodType_t type)
{
    if (type == VcselPeriodPreRange)
        return decodeVcselPeriod(readReg(PRE_RANGE_CONFIG_VCSEL_PERIOD));
    else if (type == VcselPeriodFinalRange)
        return decodeVcselPeriod(readReg(FINAL_RANGE_CONFIG_VCSEL_PERIOD));
    else
        return 255;
}

// Continuous mode control (start/stop + read) :contentReference[oaicite:2]{index=2}

void vl53_startContinuous(uint32_t period_ms)
{
    writeReg(0x80, 0x01);
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);
    writeReg(0x91, stop_variable);
    writeReg(0x00, 0x01);
    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x00);

    if (period_ms != 0)
    {
        uint16_t osc_calibrate_val = readReg16Bit(OSC_CALIBRATE_VAL);
        if (osc_calibrate_val != 0)
        {
            period_ms *= osc_calibrate_val;
        }
        writeReg32Bit(SYSTEM_INTERMEASUREMENT_PERIOD, period_ms);
        writeReg(SYSRANGE_START, 0x04); // timed
    }
    else
    {
        writeReg(SYSRANGE_START, 0x02); // back-to-back
    }
}

void vl53_stopContinuous(void)
{
    writeReg(SYSRANGE_START, 0x01);

    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);
    writeReg(0x91, 0x00);
    writeReg(0x00, 0x01);
    writeReg(0xFF, 0x00);
}

uint16_t vl53_readRangeContinuousMillimeters(void)
{
    startTimeout();
    while ((readReg(RESULT_INTERRUPT_STATUS) & 0x07) == 0)
    {
        if (checkTimeoutExpired())
        {
            did_timeout = true;
            return 65535;
        }
    }

    uint16_t range = readReg16Bit(RESULT_RANGE_STATUS + 10);
    writeReg(SYSTEM_INTERRUPT_CLEAR, 0x01);
    return range;
}

uint16_t vl53_readRangeSingleMillimeters(void)
{
    writeReg(0x80, 0x01);
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);
    writeReg(0x91, stop_variable);
    writeReg(0x00, 0x01);
    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x00);

    writeReg(SYSRANGE_START, 0x01);

    startTimeout();
    while (readReg(SYSRANGE_START) & 0x01)
    {
        if (checkTimeoutExpired())
        {
            did_timeout = true;
            return 65535;
        }
    }

    return vl53_readRangeContinuousMillimeters();
}

// ======== private helpers (getSpadInfo, timeouts, calibration) =========

static bool getSpadInfo(uint8_t *count, bool *type_is_aperture)
{
    uint8_t tmp;

    writeReg(0x80, 0x01);
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x00);

    writeReg(0xFF, 0x06);
    writeReg(0x83, readReg(0x83) | 0x04);
    writeReg(0xFF, 0x07);
    writeReg(0x81, 0x01);

    writeReg(0x80, 0x01);

    writeReg(0x94, 0x6B);
    writeReg(0x83, 0x00);
    startTimeout();
    while (readReg(0x83) == 0x00)
    {
        if (checkTimeoutExpired()) return false;
    }
    writeReg(0x83, 0x01);
    tmp = readReg(0x92);

    *count = tmp & 0x7F;
    *type_is_aperture = ((tmp >> 7) & 0x01) != 0;

    writeReg(0x81, 0x00);
    writeReg(0xFF, 0x06);
    writeReg(0x83, readReg(0x83) & (uint8_t)~0x04);
    writeReg(0xFF, 0x01);
    writeReg(0x00, 0x01);

    writeReg(0xFF, 0x00);
    writeReg(0x80, 0x00);

    return true;
}

static void getSequenceStepEnables(SequenceStepEnables *enables)
{
    uint8_t sequence_config = readReg(SYSTEM_SEQUENCE_CONFIG);

    enables->tcc         = (sequence_config >> 4) & 0x1;
    enables->dss         = (sequence_config >> 3) & 0x1;
    enables->msrc        = (sequence_config >> 2) & 0x1;
    enables->pre_range   = (sequence_config >> 6) & 0x1;
    enables->final_range = (sequence_config >> 7) & 0x1;
}

static void getSequenceStepTimeouts(const SequenceStepEnables *enables,
                                    SequenceStepTimeouts *timeouts)
{
    timeouts->pre_range_vcsel_period_pclks =
        vl53_getVcselPulsePeriod(VcselPeriodPreRange);

    timeouts->msrc_dss_tcc_mclks =
        (uint16_t)readReg(MSRC_CONFIG_TIMEOUT_MACROP) + 1U;
    timeouts->msrc_dss_tcc_us =
        timeoutMclksToMicroseconds(timeouts->msrc_dss_tcc_mclks,
                                   timeouts->pre_range_vcsel_period_pclks);

    timeouts->pre_range_mclks =
        decodeTimeout(readReg16Bit(PRE_RANGE_CONFIG_TIMEOUT_MACROP_HI));
    timeouts->pre_range_us =
        timeoutMclksToMicroseconds(timeouts->pre_range_mclks,
                                   timeouts->pre_range_vcsel_period_pclks);

    timeouts->final_range_vcsel_period_pclks =
        vl53_getVcselPulsePeriod(VcselPeriodFinalRange);

    timeouts->final_range_mclks =
        decodeTimeout(readReg16Bit(FINAL_RANGE_CONFIG_TIMEOUT_MACROP_HI));

    if (enables->pre_range)
    {
        timeouts->final_range_mclks -= timeouts->pre_range_mclks;
    }

    timeouts->final_range_us =
        timeoutMclksToMicroseconds(timeouts->final_range_mclks,
                                   timeouts->final_range_vcsel_period_pclks);
}

static uint16_t decodeTimeout(uint16_t reg_val)
{
    return (uint16_t)((reg_val & 0x00FF)
        << (uint16_t)((reg_val & 0xFF00) >> 8)) + 1U;
}

static uint16_t encodeTimeout(uint32_t timeout_mclks)
{
    uint32_t ls_byte = 0;
    uint16_t ms_byte = 0;

    if (timeout_mclks > 0)
    {
        ls_byte = timeout_mclks - 1U;

        while (ls_byte & 0xFFFFFF00UL)
        {
            ls_byte >>= 1;
            ms_byte++;
        }

        return (uint16_t)((ms_byte << 8) | (ls_byte & 0xFF));
    }
    else
    {
        return 0;
    }
}

static uint32_t timeoutMclksToMicroseconds(uint16_t timeout_period_mclks,
                                           uint8_t vcsel_period_pclks)
{
    uint32_t macro_period_ns = calcMacroPeriod(vcsel_period_pclks);
    return ((uint32_t)timeout_period_mclks * macro_period_ns + 500U) / 1000U;
}

static uint32_t timeoutMicrosecondsToMclks(uint32_t timeout_period_us,
                                           uint8_t vcsel_period_pclks)
{
    uint32_t macro_period_ns = calcMacroPeriod(vcsel_period_pclks);
    return ( (timeout_period_us * 1000U) + (macro_period_ns / 2U) )
           / macro_period_ns;
}

static bool performSingleRefCalibration(uint8_t vhv_init_byte)
{
    writeReg(SYSRANGE_START, (uint8_t)(0x01 | vhv_init_byte));

    startTimeout();
    while ((readReg(RESULT_INTERRUPT_STATUS) & 0x07) == 0)
    {
        if (checkTimeoutExpired()) return false;
    }

    writeReg(SYSTEM_INTERRUPT_CLEAR, 0x01);
    writeReg(SYSRANGE_START, 0x00);
    return true;
}

// ---------------------------------------------------------------------
// Non-blocking continuous-mode poll
//  - ASSUMES you already called vl53_startContinuous(period_ms)
//  - Returns true when a new measurement was ready and has been read
//  - Writes the distance in mm into *range_mm (if not NULL)
//  - Does NOT block; if no data ready, just returns false.
// ---------------------------------------------------------------------
bool vl53_pollRangeContinuousMillimeters(uint16_t *range_mm)
{
    // Check RESULT_INTERRUPT_STATUS (0x13), bits 2:0
    uint8_t int_status = readReg(RESULT_INTERRUPT_STATUS);

    if ((int_status & 0x07u) == 0u)
    {
        // No new sample yet
        return false;
    }

    // New sample ready ? read the 16-bit range result
    // Pololu reads from RESULT_RANGE_STATUS + 10 (0x14 + 10 = 0x1E)
    uint16_t range = readReg16Bit(RESULT_RANGE_STATUS + 10u);

    // Clear the interrupt so the sensor can assert it again for the next sample
    writeReg(SYSTEM_INTERRUPT_CLEAR, 0x01);

    if (range_mm != NULL)
    {
        *range_mm = range;
    }

    return true;
}


