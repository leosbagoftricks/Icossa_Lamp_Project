/*
 * File:   pwm.c
 * Author: leofernekes
 *
 * Created on December 1, 2025, 2:08 PM
 */


#include <xc.h>
#include "pwm.h"
#include "icossa_lamp_main.h"
#include "i2c_tof.h"
#include "gamma_table.h"
void __interrupt() isr(void)
{
    
    #define TMR1_RELOAD_H 0xF0
    #define TMR1_RELOAD_L 0x60
    
    // ---- Timer2: PWM dithering ISR ----
    
 //   LATCbits.LATC3 = 1;// DIAGNOSTIC OUT  
    if (PIR4bits.TMR2IF)
    {
        PIR4bits.TMR2IF = 0;    // clear Timer2 interrupt flag

        static uint8_t wsub;    // 8-bit accumulator, lives only in ISR
        uint16_t i = pwm16_target;  // 0..65535

        // 6 LSBs are fractional sub-PWM
        uint8_t frac = (uint8_t)(i & 0x3F);    // 0..63

        // scale fraction by 4 and accumulate
        uint8_t add = (uint8_t)(frac << 2);    // 0..252
        uint8_t old = wsub;
        wsub = (uint8_t)(wsub + add);

        // Detect overflow (CARRY equivalent): if result < old
        if (wsub < old)
        {
            // increment bit 6 ? least significant bit of 10-bit "hardware" field
            i += 0x0040;       // add 64 to word

            // avoid wrapping past max (0xFFC0)
            if (i < 0x0040)    // overflowed around 0xFFFF -> 0x0000
            {
                i -= 0x0040;   // clamp back one step
            }
        }

        // At this point, bits 15..6 of i are the 10-bit hardware duty
        // Convert that to standard 10-bit duty value (0..1023)
        uint16_t duty = i >> 6;    // extract bits 15..6

        // Clamp just in case
        if (duty > 1023)
        {duty = 1023;}

        // Write 10-bit duty to PWM3 registers (no function call)
        duty &= 0x03FF;
        PWM3DCH = (uint8_t)(duty >> 2);    // bits 9..2
        PWM3DCL = (uint8_t)(duty << 6);    // bits 1..0 into <7:6>
    }


//  void timer_handler(void)

    // Poll the Timer1 overflow flag
    if (PIR4bits.TMR1IF)
    {
        

        // Clear the flag
        PIR4bits.TMR1IF = 0;
       // LATCbits.LATC3 ^= 1;// DIAGNOSTIC OUT
        // Reload Timer1 for the next 1 ms period
        TMR1H = TMR1_RELOAD_H;
        TMR1L = TMR1_RELOAD_L;

        // Leak gesture timers down toward zero (but never underflow)
        if (gesture_timer_long > 0)
        {
            gesture_timer_long--;
        }

        if (gesture_timer_short > 0)
        {
            gesture_timer_short--;
        }
        
         if (brightness_timer > 0)
        {
            brightness_timer--;
        }       


    }

  
}// isr


#include <xc.h>
#include <stdint.h>

void pps_unlock(void)
{
    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 0;   // unlock 
}
void pps_lock(void)
{
    PPSLOCK = 0x55;
    PPSLOCK = 0xAA;
    PPSLOCKbits.PPSLOCKED = 1;   // lock 
}

void pwm3_set_duty_10bit(uint16_t duty) // 0..1023
{
    duty &= 0x03FF;
    PWM3DCH = (uint8_t)(duty >> 2);    // bits 9..2
    PWM3DCL = (uint8_t)(duty << 6);    // bits 1..0 into <7:6>
}

void init_pwm3_rc5(void)
{
    // RCX digital
    ANSELCbits.ANSC5 = 0;
    ANSELCbits.ANSC4 = 0;
    ANSELCbits.ANSC3 = 0;    
    TRISCbits.TRISC5 = 1;              // keep as input until running
    TRISCbits.TRISC4 = 1;
    TRISCbits.TRISC3 = 1;  
    
    //diagnostic pin
    ANSELAbits.ANSA2 = 0;
    TRISAbits.TRISA2 = 0;
    
    // --- Timer2 timebase ---
    // Pick your PWM frequency by PR2 and prescale.
    // PR2=0xFF gives the maximum 10-bit period range.
    PR2 = 0xFF;

    PIR4bits.TMR2IF = 0;
    T2CONbits.T2CKPS = 0b00;// 1:1 prescale
    T2CLKCON = 1; //   Clock Source FOSC/4
    T2CONbits.TMR2ON = 1;

    // Wait for first overflow (recommended order for a complete first cycle?) 
    while (!PIR4bits.TMR2IF) {;}
    PIR4bits.TMR2IF = 0;
    
 //setup PPS mappable pins   
    INTCONbits.GIE = 0;   
    // --- Route PWM3OUT to RC5 via PPS ---
    pps_unlock();
    RC5PPS = 0x0B;                     // PWM3OUT = 0x0B 
    RC4PPS = 0x0B;                     // PWM3OUT = 0x0B 
    RC3PPS = 0x0B;                     // PWM3OUT = 0x0B 
    // MSSP1 outputs -> pins
    RC0PPS = 0x15;   // SCL1OUT
    RC1PPS = 0x16;   // SDA1OUT

    // MSSP1 inputs already correct, but OK to set again:
    SSP1CLKPPS = 0x10;  // RC0
    SSP1DATPPS = 0x11;  // RC1
    pps_lock();
    INTCONbits.GIE = 1;   // no interrupts while messing with PPS
    
       
    // Configure PWM3
    PWM3CONbits.PWM3POL = 0;           // active-high (PWMxPOL) 
    pwm3_set_duty_10bit(255);

    // Enable output driver *after* timebase + PPS (recommended order) 


    SLRCONCbits.SLRC5 = 1;// fast slew Rate 
    SLRCONCbits.SLRC4 = 1;// fast slew Rate 
    SLRCONCbits.SLRC3 = 1;// fast slew Rate  
    
    TRISCbits.TRISC5 = 0;              // switch to output mode
    TRISCbits.TRISC4 = 0;
    TRISCbits.TRISC3 = 0;     
       
    
    PWM3CONbits.PWM3EN = 1;// enable PWM module (PWMxEN) 
    PIR4bits.TMR2IF = 0;   // clear flag
    PIE4bits.TMR2IE = 1;   // enable Timer2 interrupt
    INTCONbits.PEIE  = 1;  // peripheral interrupts enable
    INTCONbits.GIE   = 1;  // global interrupts enable   
    
    
    
}




//ramping system to smooth the dimming function - never a sharp change
void brightness_update_exp(void)
{
    if (brightness_timer != 0)
        return;

    brightness_timer = 20;   // update every 20 ms

    int16_t error = (int16_t)brightness_target - (int16_t)brightness_actual;

    // If error is zero ? nothing to do
    if (error == 0)
        return;

    // alpha = 1/8 smoothing
  //  brightness_actual += (error >> 3);   // >>3 = divide by 8
  // brightness_actual += (error >> 4);   // >>4 = divide by 16
    brightness_actual += (error >> 5);   // >>5 = divide by 32
    if (brightness_actual > 32767) // test and clamp max value to avoid rollover
    { brightness_actual = 32767; }
//    take 15 bit input and scale it down to 9 bits
    pwm16_target = gamma_table [(brightness_actual >> 6)];// lookup gamma corrected 16 bit value
}


uint16_t delay_filter(uint16_t d) // delay buffer: 8 samples at 15 mS = 120 mS.
{

    uint16_t i;
    
    i = delay_reg[delay_reg_pointer]; // get oldest sample in array
    delay_reg[delay_reg_pointer] = d; // save the new sample in over oldest sample
    delay_reg_pointer++; //increment pointer
        if(delay_reg_pointer > 7)
        {
        delay_reg_pointer = 0;//reset on rollover
        }
    
    return(i) ; // return the oldest sample


}


// 1 ms tick at Fosc = 16 MHz (Fcy = 4 MHz)
#define TMR1_RELOAD_H 0xF0
#define TMR1_RELOAD_L 0x60

void timer1_init_1ms_tick(void)
{
    // Stop Timer1 while configuring
    T1CONbits.TMR1ON = 0;

    T1CONbits.RD16 = 1; // 16 bit read write mode
    
// Clock source = Fosc/4 
    T1CLK = 1; // Fosc/4
    
    // Prescaler 1:1
    T1CONbits.CKPS = 0b00;   // 1:1

    // Disable Timer1 gate

    T1GCON = 0;     // gate disabled

    // Load reload value for 1 ms overflow
    TMR1H = TMR1_RELOAD_H;
    TMR1L = TMR1_RELOAD_L;

    // Clear interrupt flag 
    PIR4bits.TMR1IF = 0;

    // enable TMR1 interrupt 
    PIE4bits.TMR1IE = 1;

    // Start Timer1
    T1CONbits.TMR1ON = 1;
}

